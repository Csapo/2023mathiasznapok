﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using System.Reflection;

namespace mathiasznapok
{
    /// <summary>
    /// Interaction logic for feladat.xaml
    /// </summary>
    public partial class feladat : Window
    {
        List<feladatok> list = new List<feladatok>();
        private string Identifier;
        int szam = 0;
        List<feladatok> mat = new List<feladatok>();
        List<feladatok> tor = new List<feladatok>();
        List<feladatok> idegen = new List<feladatok>();
        List<feladatok> magy = new List<feladatok>();
        int points = 0;

        public feladat(string identifier)
        {
            InitializeComponent();
            Identifier = identifier;

            

            string[] temp = File.ReadAllLines("adatok.txt");
            for (int i = 0; i < temp.Length; i++)
            {
                try
                {
                    list.Add(new feladatok(temp[i], ';'));
                }
                catch (Exception baj)
                {
                    MessageBox.Show(baj.Message);
                }
            }


            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].Type == "matek")
                {
                    mat.Add(list[i]);
                }
                if (list[i].Type == "tortenelem")
                {
                    tor.Add(list[i]);
                }
                if (list[i].Type == ("angol"))
                {
                    idegen.Add(list[i]);
                }
                if (list[i].Type == "nemet")
                {
                    idegen.Add(list[i]);
                }
                if (list[i].Type == "magyar")
                {
                    magy.Add(list[i]);
                }
            }
            if (Identifier == "tortenelem")
            {

                question.Content = tor[szam].Question;
                answer1.Content = tor[szam].Bad_Answer_1;
                answer2.Content = tor[szam].Bad_Answer_2;
                answer3.Content = tor[szam].Good_Answer;
            }
            if (Identifier == "matek")
            {
                question.Content = mat[0].Question;
            }
            if (Identifier == "angol")
            {
                question.Content = idegen[0].Question;
            }
            if (Identifier == "magyar")
            {
                question.Content = magy[0].Question;
            }



            Title = Identifier;
        }

        private void answer1_Click(object sender, RoutedEventArgs e)
        {
            if (Identifier == "tortenelem" && answer1.Content == tor[szam].Good_Answer)
            {
                szam++;
                points++;
                game g = new game(points);
                g.Show();
                this.Close();
            }

            else
            {
                szam++;
                game g = new game(points);
                g.Show();
                this.Close();
            }
            }
     

        private void answer2_Click(object sender, RoutedEventArgs e)
        {
            if (Identifier == "tortenelem")
            {
                if (this.Content == tor[szam].Good_Answer)
                {
                    szam++;
                    points++;
                    game g = new game(points);
                    g.Show();
                    this.Close();

                }
                else
                {
                    szam++;
                    game g = new game(points);
                    g.Show();
                    this.Close();
                }
            }
        }

        private void answer3_Click(object sender, RoutedEventArgs e)
        {
            string valt = (string)answer3.Content;
            if (Identifier == "tortenelem")
            {
                if (valt == tor[szam].Good_Answer)
                {
                    szam++;
                    points++;
                    game g = new game(points);
                    g.Show();
                    this.Close();

                }
                else
                {
                    szam++;
                    game g = new game(points);
                    g.Show();
                    this.Close();
                }
            }
        }
    }
}
