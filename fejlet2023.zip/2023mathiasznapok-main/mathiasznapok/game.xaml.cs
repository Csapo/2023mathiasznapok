﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace mathiasznapok
{
    /// <summary>
    /// Interaction logic for game.xaml
    /// </summary>
    public partial class game : Window
    {
        DirectoryInfo d; //képeket tartalamzó mappa információi
        FileInfo[] Files; //mappában található állományok tölbje
        int imageIndex = 0; //Hányadik képnél tartunk?

        public game()
        {
            InitializeComponent();

            d = new DirectoryInfo("walkR");
            Files = d.GetFiles("*.*");


          BitmapImage BMI = new BitmapImage();
            BMI.BeginInit();
            BMI.UriSource = new Uri(d.FullName + @"\" + Files[imageIndex]);
            BMI.DecodePixelWidth = 120;
            BMI.EndInit();

            player.Source = BMI;
            player.Width = BMI.Width;
            player.Height = BMI.Height;
        }


        private void Window_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.Key == Key.D)
            {
                d = new DirectoryInfo("walkR");
                Files = d.GetFiles("*.*");
                imageIndex++;
                if (imageIndex == Files.Length)
                    imageIndex = imageIndex - Files.Length;

                BitmapImage BMI = new BitmapImage();
                BMI.BeginInit();
                BMI.UriSource = new Uri(d.FullName + @"\" + Files[imageIndex]);
                BMI.DecodePixelWidth = 120;
                BMI.EndInit();
                player.Source = BMI;
                player.Width = BMI.Width;
                player.Height = BMI.Height;


                Thickness newMargin = player.Margin;

                newMargin.Left += 20;

                player.Margin = newMargin;

            }
            if (e.Key == Key.A)
            {
                d = new DirectoryInfo("walkL"
              ); //Mappa megadása           
                Files = d.GetFiles("*.*"); //képek összegyűjtése
                imageIndex++;
                if (imageIndex == Files.Length)
                    imageIndex = imageIndex - Files.Length;

                BitmapImage BMI = new BitmapImage();
                BMI.BeginInit();
                BMI.UriSource = new Uri(d.FullName + @"\" + Files[imageIndex]);
                BMI.DecodePixelWidth = 120;
                BMI.EndInit();
                player.Source = BMI;
                player.Width = BMI.Width;
                player.Height = BMI.Height;

                Thickness newMargin = player.Margin;

                newMargin.Left -= 20;


                player.Margin = newMargin;
            }
            if (e.Key == Key.W)
            {
                d = new DirectoryInfo("frontwalk"
              ); //Mappa megadása           
                Files = d.GetFiles("*.*"); //képek összegyűjtése
                imageIndex++;
                if (imageIndex == Files.Length)
                    imageIndex = imageIndex - Files.Length;

                BitmapImage BMI = new BitmapImage();
                BMI.BeginInit();
                BMI.UriSource = new Uri(d.FullName + @"\" + Files[imageIndex]);
                BMI.DecodePixelWidth = 120;
                BMI.EndInit();
                player.Source = BMI;
                player.Width = BMI.Width;
                player.Height = BMI.Height;

                Thickness newMargin = player.Margin;

                newMargin.Top -= 20;


                player.Margin = newMargin;

            }

            if (e.Key == Key.S)
            {
                d = new DirectoryInfo("backwalk"
              ); //Mappa megadása           
                Files = d.GetFiles("*.*"); //képek összegyűjtése
                imageIndex++;
                if (imageIndex == Files.Length)
                    imageIndex = imageIndex - Files.Length;

                BitmapImage BMI = new BitmapImage();
                BMI.BeginInit();
                BMI.UriSource = new Uri(d.FullName + @"\" + Files[imageIndex]);
                BMI.DecodePixelWidth = 120;
                BMI.EndInit();
                player.Source = BMI;
                player.Width = BMI.Width;
                player.Height = BMI.Height;

                Thickness newMargin = player.Margin;

                newMargin.Top += 20;


                player.Margin = newMargin;
            }

            Thickness margin1 = player.Margin;
            double width1 = player.ActualWidth;
            double height1 = player.ActualHeight;

            Thickness margin2 = matek.Margin;
            double height2 = matek.ActualHeight;
            double width2 = matek.ActualWidth;

            Thickness margin3 = tori.Margin;
            double height3 = tori.ActualHeight;
            double width3 = tori.ActualWidth;

            Thickness margin4 = magyar.Margin;
            double height4 = magyar.ActualHeight;
            double width4 = magyar.ActualWidth;

            Thickness margin5 = idegen_nyelv.Margin;
            double height5 = idegen_nyelv.ActualHeight;
            double width5 = idegen_nyelv.ActualWidth;

            double x1 = margin1.Left + width1 / 2;
            double y1 = margin1.Top + height1 / 2;
            double x2 = margin2.Left + width2 / 2;
            double y2 = margin2.Top + height2 / 2;
            double x3 = margin3.Left + width3 / 2;
            double y3 = margin3.Top + height3 / 2;
            double x4 = margin4.Left + width4 / 2;
            double y4 = margin4.Top + height4 / 2;
            double x5 = margin5.Left + width5 / 2;
            double y5 = margin5.Top + height5 / 2;

            double distance = Math.Sqrt(Math.Pow(x2-x1, 2) + Math.Pow(y2-y1, 2));
            double distance2 = Math.Sqrt(Math.Pow(x3 - x1, 2) + Math.Pow(y3 - y1, 2));
            double distance3 = Math.Sqrt(Math.Pow(x4 - x1, 2) + Math.Pow(y4 - y1, 2));
            double distance4 = Math.Sqrt(Math.Pow(x5 - x1, 2) + Math.Pow(y5 - y1, 2));

            if (distance < 200)
            {
                string picName = matek.Tag.ToString();
                feladat f = new feladat(picName);
                f.Show();
                this.Hide();
            }
            if (distance2 < 200)
            {
                string picName = tori.Tag.ToString();
                feladat f = new feladat(picName);
                f.Show();
                this.Hide();
            }
            if (distance3 < 200)
            {
                string picName = magyar.Tag.ToString();
                feladat f = new feladat(picName);
                f.Show();
                this.Hide();
            }
            if (distance4 < 200)
            {
                string picName = idegen_nyelv.Tag.ToString();
                feladat f = new feladat(picName);
                f.Show();
                this.Hide();
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            
        }
    }
}
