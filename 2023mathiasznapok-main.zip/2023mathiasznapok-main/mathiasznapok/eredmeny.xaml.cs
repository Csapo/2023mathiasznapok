﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace mathiasznapok
{
    /// <summary>
    /// Interaction logic for eredmeny.xaml
    /// </summary>
    public partial class eredmeny : Window
    {
        private int pontok;
        public eredmeny(int point)
        {
            InitializeComponent();
            pontok = point;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (pontok >= 8)
            {
                win.Content = "Átmentél az érettségin";
                ponts.Content = $"Pontjaid: {pontok}";
            }
            else
            {
                win.Content = "Megbuktál az érettségin";
                ponts.Content = $"Pontjaid: {pontok}";
            }
        }
    }
}
