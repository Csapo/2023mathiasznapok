﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mathiasznapok
{
    internal class feladatok
    {
        private string question;
        private string goood_answer;
        private string bad_answer_1;
        private string bad_answer_2;
        private string type;


        public string Question
        {
            get { return question; }
            set
            {
                if (value == "")
                {
                    throw new Exception("Nincs kérdés");
                }
                question = value;
            }
        }

        public string Good_Answer
        {
            get { return goood_answer; }
            set
            {
                if (value == "")
                {
                    throw new Exception("Nincs jó válasz");
                }
                goood_answer = value;
            }
        }

        public string Bad_Answer_1
        {
            get { return bad_answer_1;}
            set
            {
                if (value == "")
                {
                    throw new Exception("Nincs rossz válasz");
                }
                bad_answer_1 = value;
            }
        }

        public string Bad_Answer_2
        {
            get { return bad_answer_2; }
            set
            {
                if (value == "")
                {
                    throw new Exception("Nincs rossz válasz");
                }
                bad_answer_2 = value;
            }
        }

        public string Type
        {
            get { return type; }
            set 
            {
                if (value == "")
                {
                    throw new Exception("Kell");
                }
                type = value;
            }
        }



        public feladatok(string adatsor, char karakter)
        {
            string[] temp = adatsor.Split(karakter);
            Question = temp[0];
            Good_Answer = temp[1];
            Bad_Answer_1 = temp[2];
            Bad_Answer_2 = temp[3];
            Type = temp[4];
        }
    }
}
