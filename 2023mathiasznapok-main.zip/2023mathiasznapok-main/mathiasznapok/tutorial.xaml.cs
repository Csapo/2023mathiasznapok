﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace mathiasznapok
{
    /// <summary>
    /// Interaction logic for tutorial.xaml
    /// </summary>
    public partial class tutorial : Window
    {
        public tutorial()
        {
            InitializeComponent();

            textbox.Text = "-Mozogni a A W S D -vel tudsz \n-ha elég közel mész egy könyvhőz és megnyomod az E billentyűt akkor megynyílik egy feladat \n-akkor tudsz tovább menni ha mind a négy feladatot megoldod \n-a játék akkor ér véget ha a négy pályán végig mentél és legalább nyolc pontot összegyűjtesz \n-sok szerentsét a játékhoz";

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
