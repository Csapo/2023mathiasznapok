﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace mathiasznapok
{
    /// <summary>
    /// Interaction logic for feladat.xaml
    /// </summary>
    public partial class feladat : Window
    {
        List<feladatok> list = new List<feladatok>();
        private string Identifier;
        public feladat(string identifier)
        {
            InitializeComponent();
            Identifier = identifier;

            string[] temp = File.ReadAllLines("adatok.txt");
            for (int i = 0; i < temp.Length; i++)
            {
                try
                {
                    list.Add(new feladatok(temp[i], ';'));
                }
                catch (Exception baj)
                {
                    MessageBox.Show(baj.Message);
                }
            }

            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].Type == identifier)
                {
                    question.Content = list[i].Question;
                }
            }
        }
    }
}
