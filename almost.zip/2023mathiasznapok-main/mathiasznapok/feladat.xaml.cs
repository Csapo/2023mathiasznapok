﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using System.Reflection;

namespace mathiasznapok
{
    /// <summary>
    /// Interaction logic for feladat.xaml
    /// </summary>
    public partial class feladat : Window
    {
        public int szam;
        public int Matszam;
        public int Magyszam;
        public int ideszam;
        public int points;
        List<feladatok> list = new List<feladatok>();
        private string Identifier;
       
        List<feladatok> mat = new List<feladatok>();
        List<feladatok> tor = new List<feladatok>();
        List<feladatok> idegen = new List<feladatok>();
        List<feladatok> magy = new List<feladatok>();


        public feladat(string identifier, int sorszam, int matszam, int magyszam, int idegszam)
        {
            InitializeComponent();
            Identifier = identifier;
            szam = sorszam;
            Matszam = matszam;
            Magyszam = magyszam;
            ideszam = idegszam;



            string[] temp = File.ReadAllLines("adatok.txt");
            for (int i = 0; i < temp.Length; i++)
            {
                try
                {
                    list.Add(new feladatok(temp[i], ';'));
                }
                catch (Exception baj)
                {
                    MessageBox.Show(baj.Message);
                }
            }


            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].Type == "matek")
                {
                    mat.Add(list[i]);
                }
                if (list[i].Type == "tortenelem")
                {
                    tor.Add(list[i]);
                }
                if (list[i].Type == ("angol"))
                {
                    idegen.Add(list[i]);
                }
                if (list[i].Type == "nemet")
                {
                    idegen.Add(list[i]);
                }
                if (list[i].Type == "magyar")
                {
                    magy.Add(list[i]);
                }
            }
            if (Identifier == "tortenelem")
            {

                question.Content = tor[szam].Question;
                answer1.Content = tor[szam].Bad_Answer_1;
                answer2.Content = tor[szam].Bad_Answer_2;
                answer3.Content = tor[szam].Good_Answer;
            }
            if (Identifier == "matek")
            {
                question.Content = mat[Matszam].Question;
                answer1.Content = mat[Matszam].Bad_Answer_1;
                answer2.Content = mat[Matszam].Good_Answer;
                answer3.Content = mat[Matszam].Bad_Answer_2;
            }
            if (Identifier == "angol")
            {
                question.Content = idegen[ideszam].Question;
                answer1.Content = idegen[ideszam].Good_Answer;
                answer2.Content = idegen[ideszam].Bad_Answer_1;
                answer3.Content = idegen[ideszam].Bad_Answer_2;
            }
            if (Identifier == "magyar")
            {
                question.Content = magy[Magyszam].Question;
                answer1.Content = magy[Magyszam].Bad_Answer_1;
                answer2.Content = magy[Magyszam].Good_Answer;
                answer3.Content = magy[Magyszam].Bad_Answer_2;
            }



            Title = Identifier;
        }

        private void answer1_Click(object sender, RoutedEventArgs e)
        {
            if (Identifier == "tortenelem")
            {
                szam++;
                this.Close();
            }
            if (Identifier == "matek")
            {
                Matszam++;
                this.Close();
            }
            if (Identifier == "angol")
            {
                ideszam++;
                points++;
                this.Close();
            }
            if (Identifier == "magyar")
            {
                Magyszam++;
                this.Close();
            }
        }
     

        private void answer2_Click(object sender, RoutedEventArgs e)
        {
            if (Identifier == "tortenelem")
            {
              szam++;
              this.Close();              
            }
            if (Identifier == "matek")
            {
                Matszam++;
                points++;
                this.Close();
            }
            if (Identifier == "angol")
            {
                ideszam++;
                this.Close();
            }
            if (Identifier == "magyar")
            {
                Magyszam++;
                points++;
                this.Close();
            }
        }

        private void answer3_Click(object sender, RoutedEventArgs e)
        {

            if (Identifier == "tortenelem")
            {
                szam++;
                points++;
                this.Close();
            }
            if (Identifier == "matek")
            {
                Matszam++;
                this.Close();
            }
            if (Identifier == "angol")
            {
                ideszam++;
                this.Close();
            }
            if (Identifier == "magyar")
            {
                Magyszam++;
                this.Close();
            }
        }
    }
}
